# STORMY (OOP)

### What is STORMY?
Stormy is content management system (CMS) written in PHP, MySQL, HTML and JS.

### How much does STORMY cost?
It's completely free.

### What may I use STORMY for?
With STORMY, you are able to build your own website in minutes. No programming skills required - just download, upload and adjust options to your needs.
