﻿<?php
  define("DB_HOST", "localhost");
  define("DB_LOGIN", "root");
  define("DB_PASSWORD", "");
  define("DB_NAME", "stormygo");
