# STORMY (OOP)
 OOP version of STORMY
